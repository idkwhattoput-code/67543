// Main JavaScript for handling the terminal logic

// Grab the necessary DOM elements
const commandInput = document.getElementById('command-input');
const outputDiv = document.getElementById('output');

// Command history (for showing previous commands)
let commandHistory = [];
let historyIndex = -1;

// Add event listener for user input
commandInput.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') {
        const input = commandInput.value.trim();
        if (input !== "") {
            processCommand(input);
            commandHistory.push(input);
            historyIndex = -1;
        }
        commandInput.value = ''; // Clear input field
    } else if (e.key === 'ArrowUp') {
        // Show previous command
        if (historyIndex < commandHistory.length - 1) {
            historyIndex++;
            commandInput.value = commandHistory[commandHistory.length - 1 - historyIndex];
        }
    } else if (e.key === 'ArrowDown') {
        // Show next command
        if (historyIndex > 0) {
            historyIndex--;
            commandInput.value = commandHistory[commandHistory.length - 1 - historyIndex];
        } else {
            historyIndex = -1;
            commandInput.value = '';
        }
    }
});

// Process the input command
function processCommand(input) {
    // Display the command in the output section
    appendOutput(`user@web:~$ ${input}`);

    // Handle basic commands (add more as needed)
    switch (input.toLowerCase()) {
        case 'help':
            appendOutput("Available commands:\n- help: Show available commands\n- echo [message]: Display a message\n- clear: Clear the terminal");
            break;
        case 'clear':
            outputDiv.innerHTML = '';
            break;
        case 'ls':
            appendOutput("file1.txt\nfile2.txt\nfolder1/");
            break;
        default:
            if (input.startsWith('echo ')) {
                appendOutput(input.slice(5));
            } else {
                appendOutput(`bash: command not found: ${input}`);
            }
            break;
    }
}

// Append output to the terminal
function appendOutput(text) {
    outputDiv.innerHTML += text + '\n';
    window.scrollTo(0, document.body.scrollHeight); // Auto-scroll to the bottom
}
